
function setup() {
	createCanvas(720, 720);
}


function draw() {
	background(128);

	fill(128, 34, 56);
	ellipse(310, 310, 50, 70);


}